package banking;

public class Customer{
    public String firstName;
    public String lastName;


    //Setters and Getters
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public void setFirstName(String Fname) { firstName = Fname; }
    public void setLastName(String Lname) { lastName = Lname; }


}
